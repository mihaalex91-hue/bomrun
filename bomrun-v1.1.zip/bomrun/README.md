# Bomrun v1

Static page + one Vercel serverless function. No third-party aggregator: prices come straight from the distributors.

- `index.html` — the whole UI (BOM parsing, pricing table, order-split optimiser, CSV export)
- `api/price.js` — POST /api/price → queries Farnell, Mouser and DigiKey in parallel. Each is enabled by its env var; with none set it returns demo data.

## Environment variables (Vercel → Settings → Environment Variables, type Secret, then Redeploy)
| Key | Where it comes from |
|---|---|
| `FARNELL_API_KEY` | partner.element14.com → My API Keys |
| `MOUSER_API_KEY` | mouser.co.uk/api-hub → Search API (arrives by email) |
| `DIGIKEY_CLIENT_ID` / `DIGIKEY_CLIENT_SECRET` | developer.digikey.com → Production App (Product Information v4) |

Old `NEXAR_*` variables are ignored and can be deleted.

## Rate limits (free tiers)
Farnell Basic 2/s & 1,000/day · Mouser 1,000/day · DigiKey 1,000/day. A 20-line check uses 20 calls per distributor, so ~50 checks/day per distributor on free tiers — enough for launch; the daily limits are raised on request once there is traffic.

## Next (v2)
Supabase auth, saved BOMs, price/stock/EOL alerts, server-side 20-line free limit, Stripe plans.
